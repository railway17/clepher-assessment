const SelectorDivider = () => (
    <div className='h-[24px] w-[1px] bg-gray-400'></div>
  );

export default SelectorDivider;