import React from 'react';

const  EmptyResult = () => (
    <span>No matches found!</span>
  );

export default EmptyResult;
