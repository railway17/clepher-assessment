import React, { memo } from 'react';

type LoadingProps = {
    isLoading: boolean
}

const  Loader = memo(function ({ isLoading }: LoadingProps) {
  if (!isLoading) {
    return (<></>);
  }

  return (
    <div className='h-full flex justify-center items-center'>
        Loading...
    </div>
  );
})

export default Loader;
