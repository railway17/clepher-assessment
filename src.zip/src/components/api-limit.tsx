import React from 'react';

const ApiLimit = () => 
    (
        <div className="h-full flex justify-center items-start">
            <p>Your API requests reached to limitation! You can try tomorrow again.</p>
        </div>
    );

export default ApiLimit;
