import { useContext, useMemo } from 'react';
import ReactChart from 'react-apexcharts';
import { StockContext } from '../../utils/contexts/StockContext';
import getChartOptions from '../../utils/chart-utils/get-chart-options';
import modifyVolumeSeries from '../../utils/chart-utils/modify-volume-series';
import modifyTimeSeriesData from '../../utils/chart-utils/modify-time-series-data';
import Loader from '../loader';
import ApiLimit from '../api-limit';

const Chart = () => {
  const { chartData, dataQuery, chartLoading } = useContext(StockContext);

  const barSeries = useMemo(()=> {
    if (!chartData) {
      return [];
    }

    return modifyVolumeSeries(chartData, dataQuery.function, dataQuery.interval)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(chartData), dataQuery.function, dataQuery.interval])
  
  const candleSeries = useMemo(()=> {
    if (!chartData) return [];

    return modifyTimeSeriesData(chartData, dataQuery.function, dataQuery.interval);
  
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(chartData), dataQuery.function, dataQuery.interval])

  const options = useMemo(()=> {
    return {
      bar: getChartOptions(chartData, "bar", dataQuery.function, dataQuery.interval),
      candle: getChartOptions(chartData),
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(chartData), dataQuery.function, dataQuery.interval])

  return (
    <div className='h-[95%] w-full lg:w-[70%] pt-6 relative'>
      <Loader isLoading={chartLoading} />
      {
        !chartLoading && chartData &&  (
          !chartData["Information"] ? (
            <>
              <div className='h-[30%] absolute bottom-[2%] opacity-40 w-full pl-5'>
                <ReactChart
                  type="bar"
                  height={"100%"}
                  series={barSeries}
                  options={options['bar']}
                />
              </div>

              <ReactChart
                height={"100%"}
                type="candlestick"
                series={candleSeries}
                options={options['candle']}
              />
            </>
          ) : (
            <ApiLimit />
          )
        )
      }
    </div>
  );
}

export default Chart;