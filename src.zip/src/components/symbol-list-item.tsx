import { SymbolResult, Symbols } from "../utils/constants"

type SymbolListItemProps = {
    item: SymbolResult;
    onItemClick: (symbol: Symbols) => void;
}

const SymbolListItem = ({item, onItemClick}: SymbolListItemProps) => {
    return (
        <div
            key={item["1. symbol"]}
            onClick={() => onItemClick(item["1. symbol"])}
            className="py-2 px-1 w-full border-b border-solid border-gray-200 flex justify-between items-center bg-white hover:bg-gray-100 cursor-pointer"
        >
            <div className="flex flex-col items-start flex-1">
            <p>
                {item["2. name"]}
            </p>
            <p className="text-sm text-gray-500">
                {item["1. symbol"]}
            </p>
            </div>

            <div className="flex flex-col items-end flex-1">
            <p>{item["4. region"]}</p>
            <p className="text-sm text-gray-500">
                {item["3. type"]}
            </p>
            </div>

        </div>
    );
}

export default SymbolListItem;